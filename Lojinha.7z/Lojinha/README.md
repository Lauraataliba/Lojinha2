# Lojinha
Projeto  com play framework da loja nega biju

##
<ol>
  <li>Cadastra avalição</li>
  <li>Carinho remoção por enum</li>
  <li>Edição</li>
  <li>listagem de produtos</li>
</ol>
