package models;

public enum Status {
	ATIVO, INATIVO
}